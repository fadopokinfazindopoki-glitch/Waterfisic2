package com.waterfisic;

import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Matemática das ondas. Mesmas ondas das cristas de espuma do THE BEST WATER. */
public final class Ondas {
    /** Direção média em que as ondas empurram (deriva). */
    public static final double DERIVA_X = 0.349;
    public static final double DERIVA_Z = 0.693;

    /** Iguais às do shader da água (ciclos inteiros a cada 24000 ticks). */
    public static final double W1 = 0.0500043;
    public static final double W2 = 0.0350814;

    private Ondas() {
    }

    /** Retorna {dh/dx, dh/dz, dh/dt, altura} no ponto (x, z) no tempo t (ticks). */
    public static double[] avaliar(double x, double z, double t) {
        t = t % 24000.0;
        double f1 = x * 0.42 + z * 0.27 - t * W1;
        double f2 = -x * 0.21 + z * 0.5 - t * W2;
        double c1 = Math.cos(f1);
        double c2 = Math.cos(f2);
        return new double[] {
                0.252 * c1 - 0.084 * c2,
                0.162 * c1 + 0.2 * c2,
                -0.03 * c1 - 0.014 * c2,
                Math.sin(f1) * 0.6 + Math.sin(f2) * 0.4
        };
    }

    /** Amplitude das ondas em blocos: cresce com chuva e tempestade. */
    public static double amplitude(World world, float delta) {
        double chuva = world.getRainGradient(delta);
        double trovao = world.getThunderGradient(delta);
        return 0.20 * (1.0 + 1.3 * chuva + 1.2 * trovao) * (Config.I.intensidade / 100.0) * (Config.I.altura / 100.0);
    }

    /** Trovoadas: 0 (tempo bom) a 1 (tempestade total). */
    public static double tempestade(World world) {
        return world.getThunderGradient(1.0F);
    }

    /** Água rasa quase não tem onda: 0.15 (raso) até 1.0 (5 blocos ou mais de fundo). */
    public static double fatorProfundidade(World world, BlockPos pos) {
        BlockPos.Mutable p = pos.mutableCopy();
        if (!world.getFluidState(p).isIn(FluidTags.WATER)) {
            p.move(0, -1, 0);
        }
        int prof = 0;
        for (int i = 0; i < 8; i++) {
            if (!world.getFluidState(p).isIn(FluidTags.WATER)) {
                break;
            }
            prof++;
            p.move(0, -1, 0);
        }
        return Math.max(0.15, Math.min(1.0, (prof - 1) / 4.0));
    }
}
