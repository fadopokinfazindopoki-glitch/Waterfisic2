package com.waterfisic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.block.BlockState;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;

/**
 * Espuma nas cristas, ondas quebrando na praia, respingos de tempestade e cachoeiras.
 * Usa partículas do próprio Minecraft, então funciona com ou sem o THE BEST WATER.
 */
public final class Particulas {
    private static final int RAIO = 18;
    private static final int[][] VIZ = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    private Particulas() {
    }

    public static void tick(MinecraftClient mc) {
        ClientWorld w = mc.world;
        ClientPlayerEntity p = mc.player;
        if (w == null || p == null || mc.isPaused() || Config.I.particulas <= 0) {
            return;
        }
        double k = Math.min(3.0, Config.I.particulas / 100.0);
        double clima = 1.0 + w.getRainGradient(1.0F) + w.getThunderGradient(1.0F);
        long t = w.getTime();
        Random r = w.getRandom();
        BlockPos.Mutable m = new BlockPos.Mutable();
        BlockPos.Mutable n = new BlockPos.Mutable();

        int amostras = (int) Math.round(48 * k);
        int yTop = p.getBlockY() + 6;
        int yBot = p.getBlockY() - 10;

        for (int i = 0; i < amostras; i++) {
            int dx = r.nextInt(2 * RAIO + 1) - RAIO;
            int dz = r.nextInt(2 * RAIO + 1) - RAIO;
            if (dx * dx + dz * dz > RAIO * RAIO) {
                continue;
            }
            int x = p.getBlockX() + dx;
            int z = p.getBlockZ() + dz;

            for (int y = yTop; y >= yBot; y--) {
                m.set(x, y, z);
                FluidState fs = w.getFluidState(m);
                if (!fs.isIn(FluidTags.WATER)) {
                    continue;
                }
                boolean queda = fs.contains(FlowableFluid.FALLING) && fs.get(FlowableFluid.FALLING);
                if (queda) {
                    cachoeira(w, n, r, x, y, z, k);
                } else {
                    m.set(x, y + 1, z);
                    if (w.getBlockState(m).isAir()) {
                        superficie(w, n, r, x, y, z, y + fs.getHeight(), t, k, clima);
                    }
                }
                break;
            }
        }
    }

    private static void superficie(ClientWorld w, BlockPos.Mutable n, Random r, int x, int y, int z,
                                   double sy, long t, double k, double clima) {
        double[] o = Ondas.avaliar(x + 0.5, z + 0.5, t);
        double crista = o[3];

        // Espuma e bolhas estourando nas cristas das ondas.
        double limite = 0.55 - 0.1 * (clima - 1.0);
        if (crista > limite && r.nextDouble() < 0.45 * Math.min(k, 2.0)) {
            double px = x + r.nextDouble();
            double pz = z + r.nextDouble();
            w.addParticle(ParticleTypes.BUBBLE_POP, px, sy + 0.01, pz, 0.0, 0.0, 0.0);
            if (r.nextInt(3) == 0) {
                w.addParticle(ParticleTypes.CLOUD, px, sy + 0.03, pz, 0.0, 0.003, 0.0);
            }
            if (crista > 0.8 || (clima > 2.0 && r.nextBoolean())) {
                w.addParticle(ParticleTypes.SPLASH, px, sy + 0.05, pz,
                        (r.nextDouble() - 0.5) * 0.06, 0.10 + r.nextDouble() * 0.06 * clima, (r.nextDouble() - 0.5) * 0.06);
            }
        }

        // Onda quebrando na praia: avança e recua em pulsos.
        for (int[] v : VIZ) {
            n.set(x + v[0], y, z + v[1]);
            BlockState b = w.getBlockState(n);
            if (b.isAir() || !w.getFluidState(n).isEmpty()) {
                continue;
            }
            double surto = (Math.sin(t * 0.07 + (x + z) * 0.3) + 1.0) / 2.0;
            if (surto > 0.75 && r.nextDouble() < 0.5 * Math.min(k, 2.0)) {
                double px = x + 0.5 + v[0] * 0.45 + (r.nextDouble() - 0.5) * 0.6;
                double pz = z + 0.5 + v[1] * 0.45 + (r.nextDouble() - 0.5) * 0.6;
                w.addParticle(ParticleTypes.BUBBLE_POP, px, sy + 0.03, pz, 0.0, 0.0, 0.0);
                w.addParticle(ParticleTypes.BUBBLE_POP, px + 0.1, sy + 0.03, pz - 0.1, 0.0, 0.0, 0.0);
                w.addParticle(ParticleTypes.CLOUD, px, sy + 0.04, pz, v[0] * 0.01, 0.004, v[1] * 0.01);
                w.addParticle(ParticleTypes.SPLASH, px, sy + 0.05, pz, v[0] * 0.05, 0.12 + r.nextDouble() * 0.08, v[1] * 0.05);
            }
            break;
        }
    }

    private static void cachoeira(ClientWorld w, BlockPos.Mutable n, Random r, int x, int y, int z, double k) {
        int yb = y;
        for (int i = 0; i < 24; i++) {
            n.set(x, yb - 1, z);
            FluidState f = w.getFluidState(n);
            if (f.isIn(FluidTags.WATER) && f.contains(FlowableFluid.FALLING) && f.get(FlowableFluid.FALLING)) {
                yb--;
            } else {
                break;
            }
        }
        double cx = x + 0.5;
        double cz = z + 0.5;
        int alt = y - yb + 1;

        // Gotas escorrendo pela queda.
        if (r.nextDouble() < 0.6 * Math.min(k, 2.0)) {
            w.addParticle(ParticleTypes.FALLING_WATER, cx + (r.nextDouble() - 0.5) * 0.7,
                    yb + r.nextDouble() * alt, cz + (r.nextDouble() - 0.5) * 0.7, 0.0, -0.2, 0.0);
        }
        // Respingo e névoa na base.
        if (r.nextDouble() < 0.5 * Math.min(k, 2.0)) {
            double v = 0.10 + Math.min(alt, 10) * 0.012;
            w.addParticle(ParticleTypes.SPLASH, cx + (r.nextDouble() - 0.5) * 0.6, yb + 0.4,
                    cz + (r.nextDouble() - 0.5) * 0.6, (r.nextDouble() - 0.5) * v, v + r.nextDouble() * 0.1,
                    (r.nextDouble() - 0.5) * v);
            w.addParticle(ParticleTypes.CLOUD, cx + (r.nextDouble() - 0.5) * 0.8, yb + 0.3,
                    cz + (r.nextDouble() - 0.5) * 0.8, 0.0, 0.015, 0.0);
            w.addParticle(ParticleTypes.BUBBLE_POP, cx + (r.nextDouble() - 0.5), yb + 0.9,
                    cz + (r.nextDouble() - 0.5), 0.0, 0.0, 0.0);
        }
    }
}
