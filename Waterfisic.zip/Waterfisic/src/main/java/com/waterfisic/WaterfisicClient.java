package com.waterfisic;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class WaterfisicClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // A superfície da água sobe e desce de verdade (shader).
        Visual.iniciar();

        // O barco que o jogador pilota é simulado no cliente dele, então a onda também age aqui.
        ClientTickEvents.END_WORLD_TICK.register(world -> Fisica.tick(world, world.getEntities()));
        // Espuma, respingos e cachoeiras feitos com partículas do próprio Minecraft.
        ClientTickEvents.END_CLIENT_TICK.register(Particulas::tick);
    }
}
