package com.waterfisic.mixin;

import com.waterfisic.Config;
import com.waterfisic.Ondas;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.BoatEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Inclina o casco do barco acompanhando a inclinação da onda (só visual, no cliente). */
@Mixin(BoatEntityRenderer.class)
public abstract class BoatRendererMixin {
    @Inject(
            method = "render(Lnet/minecraft/entity/vehicle/BoatEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"),
            require = 0)
    private void waterfisic$inclinar(BoatEntity boat, float yaw, float tickDelta, MatrixStack matrices,
                                     VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        if (Config.I.intensidade <= 0 || !boat.isTouchingWater()) {
            return;
        }
        World w = boat.getWorld();
        double x = MathHelper.lerp(tickDelta, boat.prevX, boat.getX());
        double z = MathHelper.lerp(tickDelta, boat.prevZ, boat.getZ());
        double[] o = Ondas.avaliar(x, z, w.getTime() + tickDelta);
        double amp = Ondas.amplitude(w, tickDelta) * Ondas.fatorProfundidade(w, boat.getBlockPos());
        double gx = o[0] * amp * 1.8;
        double gz = o[1] * amp * 1.8;
        double mag = Math.sqrt(gx * gx + gz * gz);
        if (mag < 1.0E-4) {
            return;
        }
        float ang = (float) Math.atan(mag);
        matrices.multiply(new Quaternionf().fromAxisAngleRad((float) (-gz / mag), 0.0F, (float) (gx / mag), ang));
    }
}
