#version 150

#moj_import <light.glsl>
#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 ChunkOffset;
uniform int FogShape;
uniform float GameTime;
uniform vec4 AguaFase;   // x = fase da onda 1, y = fase da onda 2, z = altura (blocos), w = 1 ligado
uniform vec4 AguaFase2;  // x = fase da marolinha

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// Frequencias com numero inteiro de ciclos a cada 24000 ticks: sem "pulo" na virada do dia.
const float W1 = 0.0500043;
const float W2 = 0.0350814;
const float W3 = 0.1256637;

void main() {
    vec3 pos = Position + ChunkOffset;
    vec4 cor = Color;

    // Agua = topo com altura quebrada (nao inteira) + cor com tinta do bioma (nao cinza).
    float fy = fract(Position.y);
    float sat = max(max(Color.r, Color.g), Color.b) - min(min(Color.r, Color.g), Color.b);

    if (AguaFase.w > 0.5 && fy > 0.04 && fy < 0.96 && sat > 0.08) {
        float t = mod(GameTime * 24000.0, 24000.0);

        float f1 = pos.x * 0.42 + pos.z * 0.27 + AguaFase.x - t * W1;
        float f2 = -pos.x * 0.21 + pos.z * 0.5 + AguaFase.y - t * W2;
        float f3 = pos.x * 0.9 + pos.z * 0.6 + AguaFase2.x - t * W3;

        float h = sin(f1) * 0.6 + sin(f2) * 0.4;
        float chop = sin(f3);

        // Mesmas ondas da fisica dos barcos + marolinha so visual.
        pos.y += h * AguaFase.z + chop * AguaFase.z * 0.15;

        // Brilho pela inclinacao da onda e espuma branca nas cristas.
        float gx = 0.252 * cos(f1) - 0.084 * cos(f2);
        float gz = 0.162 * cos(f1) + 0.2 * cos(f2);
        float luz = clamp(1.0 + (gx * 0.7 + gz * 0.5) * 1.6 + 0.05 * cos(f3), 0.72, 1.32);
        cor.rgb *= luz;
        cor.rgb += vec3(0.10, 0.12, 0.13) * smoothstep(0.70, 1.0, h);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    vertexDistance = fog_distance(pos, FogShape);
    vertexColor = cor * minecraft_sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}
